# Send This to Your Crush 💘
Have a crush and want to ask them out? Why not send them a landing page instead of a boring old text message or awkward in-person confession? With [send-this-to-your-crush.live](http://send-this-to-your-crush.live/) you can express your love in style with a cute message and fun interactions! 
<div align="center">
  <img src="demo.gif" alt="demo">
 </div>

# Contributing 🤝
Have an idea to make this landing page even better? Feel free to contribute by forking the repository and submitting a pull request. But please, keep it 💖-friendly (we're trying to win hearts, not offend them!).

# Disclaimer ⚠️
We cannot guarantee that this landing page will result in a successful date or relationship. Use at your own risk (but hey, at least you tried, right?).
